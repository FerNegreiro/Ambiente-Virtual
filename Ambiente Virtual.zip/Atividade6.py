python3 -m venv myenv
source myenv/bin/activate  # Para Linux/Mac
myenv\Scripts\activate.bat  # Para Windows


tarefas = [
    {"nome": "Estudar Python", "descricao": "Estudar Python por uma hora todos os dias", "prioridade": "Alta", "categoria": "Estudo", "concluida": False},
    {"nome": "Fazer compras", "descricao": "Comprar itens essenciais no supermercado", "prioridade": "Média", "categoria": "Compras", "concluida": False},
    # Adicione mais tarefas conforme necessário
]

def adicionar_tarefa(nome, descricao, prioridade, categoria):
    tarefa = {"nome": nome, "descricao": descricao, "prioridade": prioridade, "categoria": categoria, "concluida": False}
    tarefas.append(tarefa)

def listar_tarefas():
    for idx, tarefa in enumerate(tarefas, start=1):
        print(f"Tarefa {idx}: {tarefa['nome']} - {tarefa['descricao']}")

def marcar_como_concluida(numero_tarefa):
    tarefas[numero_tarefa - 1]['concluida'] = True

def exibir_por_prioridade(prioridade):
    for tarefa in tarefas:
        if tarefa['prioridade'] == prioridade:
            print(tarefa)

# Adicione mais funções conforme necessário


def menu():
    while True:
        print("\nMenu:")
        print("1. Adicionar Tarefa")
        print("2. Listar Tarefas")
        print("3. Marcar Tarefa como Concluída")
        print("4. Exibir Tarefas por Prioridade")
        print("5. Sair")

        escolha = input("Escolha uma opção: ")

        if escolha == "1":
            nome = input("Nome da Tarefa: ")
            descricao = input("Descrição: ")
            prioridade = input("Prioridade: ")
            categoria = input("Categoria: ")
            adicionar_tarefa(nome, descricao, prioridade, categoria)
        elif escolha == "2":
            listar_tarefas()
        elif escolha == "3":
            numero_tarefa = int(input("Digite o número da tarefa a ser marcada como concluída: "))
            marcar_como_concluida(numero_tarefa)
        elif escolha == "4":
            prioridade = input("Digite a prioridade para exibir as tarefas: ")
            exibir_por_prioridade(prioridade)
        elif escolha == "5":
            print("Saindo...")
            break
        else:
            print("Opção inválida. Por favor, escolha uma opção válida.")

if __name__ == "__main__":
    menu()
